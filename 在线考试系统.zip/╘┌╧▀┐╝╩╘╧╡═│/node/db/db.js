const config = require('../models/config')

const { Sequelize } = require('sequelize')

module.exports = new Sequelize(config.config.database, config.config.user, config.config.password, {
  dialect: 'mysql',
  host: config.config.host,
  pool: {
    max: 20,
    min: 0,
    idle: 30000,
  },
  port: '3306',
  timezone: '+08:00',
})
