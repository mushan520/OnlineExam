const {
  Model,
  DataTypes,
} = require('sequelize')

const sequelize = require('../db/db')

class User extends Model {}
User.init(
  {
    instId: {
          type: DataTypes.BIGINT.UNSIGNED,
          primaryKey: true,
      },
      username: DataTypes.STRING(255),
      password: DataTypes.STRING(255),
      classId: DataTypes.STRING(255),
      stuId: DataTypes.JSON
  },
  {
    modelName: 'User', 
    sequelize,
    tableName: 'user',
    timestamps: false
  }
)


module.exports = User
