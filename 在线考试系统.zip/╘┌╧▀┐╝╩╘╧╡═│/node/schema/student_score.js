const {
  Model,
  DataTypes,
} = require('sequelize')

const sequelize = require('../db/db')

class StudentScore extends Model {}
StudentScore.init(
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      primaryKey: true,
    },
    student_id: DataTypes.INTEGER,
    exam_id:DataTypes.STRING(255),
    score:DataTypes.INTEGER
  },
  {
    modelName: 'StudentScore', 
    sequelize,
    tableName: 'student_score',
    timestamps: false
  }
)

const Student = require('./student')
StudentScore.belongsTo(Student, { foreignKey: 'student_id', targetKey: 'stuId', as: 'student_model' })

const Exam = require('./exam')
StudentScore.belongsTo(Exam, { foreignKey: 'exam_id', targetKey: 'id', as: 'exam_model' })

module.exports = StudentScore
