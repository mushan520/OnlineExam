const {
  Model,
  DataTypes,
} = require('sequelize')

const sequelize = require('../db/db')

class Exam extends Model {}
Exam.init(
  {
      id: {
          type: DataTypes.BIGINT.UNSIGNED,
          primaryKey: true,
      },
      questions: DataTypes.JSON,
      exam_name: DataTypes.STRING(255),
      score: DataTypes.STRING(255),
  },
  {
    modelName: 'Exam', 
    sequelize,
    tableName: 'exam',
    timestamps: false
  }
)

module.exports = Exam
