const {
  Model,
  DataTypes,
} = require('sequelize')

const sequelize = require('../db/db')

class Student extends Model {}
Student.init(
  {
      stuId: {
          type: DataTypes.BIGINT.UNSIGNED,
          primaryKey: true,
      },
      name: DataTypes.STRING(255),
      password: DataTypes.STRING(255),
      classId: DataTypes.STRING(255)
  },
  {
    modelName: 'Student', 
    sequelize,
    tableName: 'student',
    timestamps: false
  }
)

module.exports = Student
