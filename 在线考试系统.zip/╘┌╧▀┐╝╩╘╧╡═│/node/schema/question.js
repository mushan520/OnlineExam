const {
  Model,
  DataTypes,
} = require('sequelize')

const sequelize = require('../db/db')

class Question extends Model {}
Question.init(
  {
      id: {
          type: DataTypes.BIGINT.UNSIGNED,
          primaryKey: true,
      },
      type: DataTypes.STRING(255),
      grade: DataTypes.STRING(255),
      answer: DataTypes.STRING(255),
      choice: DataTypes.JSON,
      questionstem: DataTypes.STRING(600)
  },
  {
    modelName: 'Question', 
    sequelize,
    tableName: 'question',
    timestamps: false
  }
)

module.exports = Question
