const Router = require('koa-router');
const fs = require('fs')
var router = new Router({
  //路由前缀
	prefix: '/upload'
});

var multer = require('koa-multer')

router.post('/upload', multer({
  //设置文件存储路径
  dest: 'public/img'
}).array('file', 1), function (ctx, next) {
  let files = ctx.req.files;
  console.log(ctx.req.files,'=========')
  let file = files[0];
  let fileInfo = {};
  let path = 'public/img/' + Date.now().toString() + '_' + file.originalname;
  fs.renameSync('./public/img/' + file.filename, path);
  //获取文件基本信息
  fileInfo.type = file.mimetype;
  fileInfo.name = file.originalname;
  fileInfo.size = file.size;
  fileInfo.path = path;
  ctx.body = {
    code: 0,
    msg: 'OK',
    data: fileInfo
  }
});

module.exports = router;