const path = require('path')

exports.config = {
	uploadsGoodsPath: path.join(__dirname, '../public/uploads'),  // 上传的图片所放置的文件夹
	host: '127.0.0.1', // 数据库的地址
  user: 'root', // 账号
  password: '123456', // 密码
	database: 'exam_student', // 数据库名称
}