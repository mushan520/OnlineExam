const mysql = require('mysql');
exports.getConnection = function(){
	let connection = mysql.createConnection({
		host: '127.0.0.1',
		database: 'exam_student',
		user: 'root',
		password: 'root'
	});
	connection.connect();
	return connection;
};
