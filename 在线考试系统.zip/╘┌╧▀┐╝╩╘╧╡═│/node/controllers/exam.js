const AipOcrClient = require("aip-node-sdk-4.15.1").ocr;

const Question = require('../schema/question')
const Student = require('../schema/student')
const Exam = require('../schema/exam')
const StudentScore = require('../schema/student_score')
const User = require('../schema/user')

const Sequelize = require('sequelize')
const sequelize = require('../db/db')

var APP_ID = "22946880";
var API_KEY = "63lkfXPsgBryURCrlUUWliGM";
var SECRET_KEY = "KFEFea1qf5m9dzINa7KMh7nkTy85ldqg";

var fs = require('fs');
const {resolve} = require('path')
const path = require('path')

var client = new AipOcrClient(APP_ID, API_KEY, SECRET_KEY);

var sessionIsExam = {}

// 查询一个考试详情
exports.queryExamDetail = async function(ctx, next){
  const data = ctx.request.body;
  // 查询考试
  let questions = await Question.findAll()

  ctx.body = {
    respCode: "1",
    data:questions
  };
};

// 成绩录入(包含上传图片到本地,在把图片)
exports.addGrade = async function(ctx, next){

  const data = ctx.request.body;
  var fullPath =  path.join(process.cwd(),data.imageUrl);

  // 上传图片识别
  var image = fs.readFileSync(fullPath);
  
  const buf1 = Buffer.from(image);
  
	var base64Img = buf1.toString('base64');
  let resultA = await client.generalBasic(base64Img)

  // 答案数组
  let questions = await Question.findAll({attributes: ['answer']})

  // 试卷分数
  let exam_score = await Exam.findOne({attributes: ['score']})

  let score = 0
  if (resultA.words_result.length) {
    score = exam_score._previousDataValues.score / questions.length * resultA.words_result.length
  }

  const {
    uuid_short
  } = (
    await sequelize.query("SELECT UUID_SHORT() AS uuid_short", { type: Sequelize.QueryTypes.SELECT })
  )[0]

  let question_data = {
    id:uuid_short,
    student_id:1,
    exam_id:'98979190132441097',
    score:score
  }

  await StudentScore.create({
    ...question_data
  })
  
  ctx.body = {
    respCode: "1",
    respMsg: `恭喜你本次考试获得${score}分`
  };
};

// 查询学生成绩列表
exports.queryStudentGrade = async function(ctx, next){
  const data = ctx.request.body;
  console.log(data,'数据')
  let { keywords,limit,offset } = data

  let options = {
    include: [
      { model: Student, as: 'student_model' },
      { model: Exam, as: 'exam_model' }
    ]
  }

  let where = {}

  if (keywords) {
    where['name'] = {
      [Sequelize.Op.like]: `%${keywords}%`,
    }
  }

  if (where) {
    options.include[0]['where'] = where
  }

  if (limit) {
    options['limit'] = parseInt(limit)
  }

  if (offset) {
    options['offset'] = (parseInt(offset) - 1) * parseInt(limit)
  }

  const {
    count,
    rows: arr,
  } = await StudentScore.findAndCountAll(options)

  let array = []

  arr.forEach(item => {
    let object = {
      score: item.dataValues.score,
      exam_name:item.dataValues.exam_model.dataValues.exam_name,
      student_name: item.dataValues.student_model.dataValues.name,
      student_num: item.dataValues.student_model.dataValues.stuId
    }
    array.push(object)
  })
  
  ctx.body = {
    respCode: "1",
    data: {
      arr: array,
      count: count
    }
  };
};

// 查询试卷列表
exports.queryExamList = async function(ctx, next){
  const data = ctx.request.body;
  console.log(data,'数据')
  let { keywords, limit, offset } = data

  let options = {
    where: {
      exam_name: {
        [Sequelize.Op.like]: `%${keywords}%`,
      }
    }
  }

  if (limit) {
    options['limit'] = parseInt(limit)
  }

  if (offset) {
    options['offset'] = (parseInt(offset) - 1) * parseInt(limit)
  }

  const {
    count,
    rows: arr,
  } = await Exam.findAndCountAll(options)
  
  ctx.body = {
    respCode: "1",
    data: {
      arr: arr,
      count: count
    }
  };
};

// 查询题库列表
exports.queryQuestionList = async function(ctx, next){
  const data = ctx.request.body;
  console.log(data,'数据')
  let { keywords,limit,offset } = data

  let options = {}

  let where = {}

  if (keywords) {
    where['questionstem'] = {
      [Sequelize.Op.like]: `%${keywords}%`,
    }
  }

  if (where) {
    options['where'] = where
  }

  if (limit) {
    options['limit'] = parseInt(limit)
  }

  if (offset) {
    options['offset'] = (parseInt(offset) - 1) * parseInt(limit)
  }

  const {
    count,
    rows: arr,
  } = await Question.findAndCountAll(options)
  
  ctx.body = {
    respCode: "1",
    data: {
      arr: arr,
      count: count
    }
  };
};

// 查询学生列表
exports.queryStudentList = async function(ctx, next){
  const data = ctx.request.body;
  console.log(data,'数据')
  let { keywords,limit,offset } = data

  let options = {}

  let where = {}

  if (keywords) {
    where['name'] = {
      [Sequelize.Op.like]: `%${keywords}%`,
    }
  }

  if (where) {
    options['where'] = where
  }

  if (limit) {
    options['limit'] = parseInt(limit)
  }

  if (offset) {
    options['offset'] = (parseInt(offset) - 1) * parseInt(limit)
  }

  const {
    count,
    rows: arr,
  } = await Student.findAndCountAll(options)
  
  ctx.body = {
    respCode: "1",
    data: {
      arr: arr,
      count: count
    }
  };
};

// 添加学生
exports.addStudent = async function(ctx, next){
  const data = ctx.request.body;
  console.log(data,'数据')

  const {
    count
  } = await Student.findAndCountAll()

  await Student.create({
    ...data,
    stuId: count + 1
  })
  
  ctx.body = {
    respCode: "1",
    respMsg: "保存成功"
  };
};

// 保存试卷
exports.saveExam = async function(ctx, next){
  const data = ctx.request.body;
  let bab = JSON.parse(data.paperInfo)

  const {
    uuid_short
  } = (
    await sequelize.query("SELECT UUID_SHORT() AS uuid_short", { type: Sequelize.QueryTypes.SELECT })
  )[0]

  let names = Object.keys(bab.questionObjects[0].knowledgePointInfo)

  let aaa = {
    id:uuid_short,
    exam_name: names[0] + '考试',
    score: data.totalScore,
    questions:[1,2,3]
  }

  await Exam.create({
    ...aaa,
    id: uuid_short
  })
  
  ctx.body = {
    respCode: "1",
    respMsg: "试卷生成成功！"
  };
};

// 保存试题
exports.saveAnswer = async function(ctx, next){
    const data = ctx.request.body;
    console.log(data,'数据')

    const uuid_short = Math.floor((Math.random()+Math.floor(Math.random()*9+1))*Math.pow(10,15-1));

    console.log(uuid_short,'=[]=[]')

    await Question.create({
      ...data,
      id: uuid_short
    })
    
    ctx.body = {
			respCode: "1",
			respMsg: "交卷成功！"
		};
};

//查询当前是否有将要进行的考试
exports.query = async function(ctx, next){
	try {
    const data = ctx.request.body;

			console.log(data.stuId);

			if(!sessionIsExam[data.stuId]) {
				ctx.body = {
					respCode: 1,
					"paperId": 38,
	        "instId" : 26
				};
				// sessionIsExam[data.stuId] = true;
			}
			else {
				ctx.body = {
					respCode: -1,
					respMsg : "你当前没有要进行的考试或者你已经考试过了"
				};
			}

  }catch(e){
    console.log('[/exam/query] error:', e.message, e.stack);
    ctx.body = {
			respCode: e.code || -1,
			respMsg: e.message
		};
  }
};

//得到试卷的所有题目
exports.getQuestion = async function(ctx, next){
	try {
    const data = ctx.request.body;

      console.log(data.paperId);
      console.log(data.instId);

			let now = new Date();
			let startTime = now;
			let endTime = new Date( now.setHours( now.getHours() + 2 ) );
      ctx.body = {
          "respCode": "1",
          "instId" : 26,
          "startTime" : startTime,
          "endTime" : endTime,
          "questions": [{
            "questionstem": "有3个节点的二叉树可能有（）种",
            "choice": ["5","13","12","15"],
            "questionType": 2
          }, {
            "questionstem": "将一棵二叉树的根节点放入队列，然后将队头元素出队，将出队结点所有子节点入队，递归执行上述操作。以上操作可以实现哪种遍历",
            "choice": ["前序遍历","中序遍历","后序遍历","层序遍历"],
            "questionType": 2
          }, {
            "questionstem": "下面哪一个地址不能用作某个局域网内网IP（）",
            "choice": ["192.168.201.114","172.16.4.25","127.0.0.1","10.0.0.1"],
            "questionType": 2
          }, {
            "questionstem": "计算机的工作是通过CPU一条一条地执行_________来完成",
            "questionType": 1
          }, {
            "questionstem": "操作系统主要有五种功能： __________ 、存储管理、文件管理、设备管理和作业管理。",
            "questionType": 1
          }, {
            "questionstem": "磁盘存储器是由（  ）组成的。",
            "choice": ["磁盘", "通道", "驱动器结构", "控制器","缓冲区"],
            "questionType": 3
          },{
            "questionstem": "数据分段在OSI哪一层( )",
            "choice": ["应用层", "表示层", "传输层", "网络层","数据链路层","会话层"],
            "questionType": 3
          },{
            "questionstem": "若在一棵(分类)平衡树T中先删除某结点N,然后再插入该结点N,得到的新的平衡树T1,则T和T1不一定相同。但是如果在T上先插入结点M,然后再删除M结点,那么得到的新的平衡树T2一定与T完全相同",
            "questionType": 4
          }, {
            "questionstem": "HTTP/1.0 协议采用一次一连接。",
            "questionType": 4
          }, {
            "questionstem": "在操作系统中为什么要引入线程？",
            "questionType": 5
          }, {
            "questionstem": "请简述你对前端组件化、模块化的理解。",
            "questionType": 5
          }, {
            "questionstem": "把一个数组最开始的若干个元素搬到数组的末尾，我们称之为数组的旋转。 输入一个非递减排序的数组的一个旋转，输出旋转数组的最小元素。 例如数组{3,4,5,1,2}为{1,2,3,4,5}的一个旋转，该数组的最小值为1。 NOTE：给出的所有元素都大于0，若数组大小为0，请返回0。",
            "questionType": 6
          }, {
            "questionstem": "请实现一个函数，将一个字符串中的空格替换成“%20”。例如，当字符串为We Are Happy.则经过替换之后的字符串为We%20Are%20Happy。",
            "questionType": 6
          }],
        };

  }catch(e){
    console.log('[/exam/query] error:', e.message, e.stack);
    ctx.body = {
			respCode: e.code || -1,
			respMsg: e.message
		};
  }
};

//交卷
exports.submit_paper = async function(ctx, next){
	try {
    const data = ctx.request.body;
    console.log("instId为"+data.instId+"的学生已经交卷，他的答案为："+data.answer);
    ctx.body = {
			respCode: "1",
			respMsg: "交卷成功！"
		};

  }catch(e){
    console.log('[/exam/query] error:', e.message, e.stack);
    ctx.body = {
			respCode: e.code || -1,
			respMsg: e.message
		};
  }
};
