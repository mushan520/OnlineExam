export const  Q_SINGLE = 'Q_SINGLE'
export const  Q_MULTIPLE= 'Q_MULTIPLE'
export const  Q_TRUE_OR_FALSE= 'Q_TRUE_OR_FALSE'
