export const  CLASS_INFO = 'CLASS_INFO'
