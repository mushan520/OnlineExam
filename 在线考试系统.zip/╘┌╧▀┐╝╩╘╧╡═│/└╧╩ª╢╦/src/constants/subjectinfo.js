export const  SUBJECT_INFO = 'SUBJECT_INFO'
