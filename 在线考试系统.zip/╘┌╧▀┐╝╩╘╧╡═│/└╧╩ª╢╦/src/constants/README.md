# Redux 的 actions 和 reducers 都会用到的常量，统一放在这里。
