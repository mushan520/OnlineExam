<template lang="html">
  <div class="exam-notice">
    <el-card class="box-card">
    <div slot="header" class="clearfix">
      <h2>考试须知</h2>
    </div>
    <div class="text">
      <p>一、考试为选择题</p>
      <p>二、考试答案写在纸上，最后以图片的形式上传</p>
      <p>三、本系统会识别图片上的答案进行判卷</p>
    </div>
  </el-card>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
.exam-notice {
  margin-top: 50px
}
</style>
